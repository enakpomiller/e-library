-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 04, 2019 at 02:40 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unical_lab`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(20) NOT NULL auto_increment,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `category` varchar(40) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `category`, `first_name`, `last_name`) VALUES
(1, 'chris', '1234', 'super', 'Christian', 'Nwachukwu'),
(2, 'Daf', '1234', 'staff', 'Daf', 'Bennard');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(10) NOT NULL auto_increment,
  `booktitle` varchar(200) NOT NULL,
  `author` varchar(30) NOT NULL,
  `department` varchar(50) NOT NULL,
  `edition` varchar(10) NOT NULL,
  `sbn` varchar(20) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY  (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `booktitle`, `author`, `department`, `edition`, `sbn`, `filename`, `date`) VALUES
(1, 'Web Analysis and Activities ', 'Christian Nwachukwu', 'Technology', '', '2345', 'lnoa.pdf', '6:41am on Wednesday 13th December 2017'),
(2, 'Freelancing Tech and skills to know', 'Christian Nwachukwu', 'Art', '3rd', '2345', 'CompilerConstruction1.pdf', '6:51am on Wednesday 13th December 2017'),
(3, 'Advanced Web Development', 'Christian Nwachukwu', 'Art', '3rd', '2345', 'CompilerConstruction1.pdf', '6:51am on Wednesday 13th December 2017'),
(4, 'HTML and CSS design and build websites', 'Christian Nwachukwu', 'History', '3rd', '2345', '', '6:54am on Wednesday 13th December 2017'),
(5, 'HTML and CSS design and build websites using php7', '', 'History', '', '', 'd8a3ab6d9fd27366c6a6d1c73e3fb8603d62.pdf', '7:02am on Wednesday 13th December 2017'),
(6, 'dd', '', 'Art', '', '', 'Docs%5CITIIBTechIISemLecCOA.pdf', '7:03am on Wednesday 13th December 2017'),
(7, 'File organization and management', '', 'Art', '', '', 'Docs%5CITIIBTechIISemLecCOA.pdf', '7:03am on Wednesday 13th December 2017'),
(8, 'HTML and CSS design and build websites', '', 'History', '', '', '', '7:11am on Wednesday 13th December 2017'),
(9, 'The five hubs or scienct', 'Christian Nwachukwu', 'Science', '', '', 'CompilerConstruction1.pdf', '7:11am on Wednesday 13th December 2017'),
(10, 'Science in Agriculture ', '', 'Science', '', '', 'lnoa.pdf', '7:16am on Wednesday 13th December 2017'),
(11, 'Crypto Currency tech ', '', 'Science', '', '', 'lnoa.pdf', '7:18am on Wednesday 13th December 2017'),
(12, 'Ancient Trifecta of Nigeria ', 'Christian Nwachukwu', 'History', '', '', '', '9:15am on Wednesday 13th December 2017'),
(13, 'this is a test', 'chru', 'Science', '3', '12465', 'Christian_Nwachukwu CV updated.docx', '3:21pm on Wednesday 14th August 2019'),
(14, 'Dr Elele Lecture note', 'Dr Ele', 'Computer_Science', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '12:24 pm on Monday 30th September 2019'),
(15, 'Dr Elele Lecture note', 'Dr Ele', 'Computer_Science', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '12:24 pm on Monday 30th September 2019'),
(16, 'Dr Elele Lecture note', 'Dr Ele', 'Computer_Science', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '12:30 pm on Monday 30th September 2019'),
(17, 'Dr Elele Lecture note', 'Dr Ele', 'Computer_Science', '24th editi', '1234', 'ChristianNwachukwuProfile.pdf', '12:32 pm on Monday 30th September 2019'),
(18, 'Dr Elele Lecture note', 'Daf Bennard', 'Botany', '24th editi', '1234', '281 assignment.pdf', '02:43 pm on Monday 30th September 2019'),
(19, 'Dr Elele Lecture note ddddaa', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'csc 202 assignment.docx', '07:39 am on Tuesday 1st October 2019'),
(20, 'Dr Elele Lecture vib', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'invariants.pdf', '07:49 am on Tuesday 1st October 2019'),
(21, 'Dr Elele Lecture kisnhs', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'Am free indeed.txt', '07:55 am on Tuesday 1st October 2019'),
(22, 'dsdsdv dsdsd', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '07:58 am on Tuesday 1st October 2019'),
(23, 'dsdsdv dsdsd', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '07:59 am on Tuesday 1st October 2019'),
(24, 'dsdsdv dsdsd', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'CSC 351 Dr Ele 19-04-2018.pdf', '08:09 am on Tuesday 1st October 2019'),
(25, 'dsdsdv dsdsd', 'Brain Duckk', 'Agric_Economics', '24th editi', '1234', 'OS Answers.pdf', '08:10 am on Tuesday 1st October 2019'),
(26, 'File organization and managements', 'Daf Bennard', 'Crop_Science', '24th editi', '1234', 'Csc222 exam.pdf', '08:19 am on Tuesday 1st October 2019'),
(27, 'File organization and managementsffsfsf', 'Daf Bennard', 'Crop_Science', '24th editi', '1234', 'BEKCHANOV OTABEK CONTRACT LETTER OF EMPLOYMENT ( CONFIDENTIAL ).doc', '12:51 pm on Tuesday 1st October 2019'),
(28, 'Dr Elele Lecture note', 'Christian Nwachukwu', 'Food_Science_Technology', '24th editi', '1234', 'Student Run.docx', '02:25 pm on Tuesday 1st October 2019'),
(29, 'md sdsdsd', 'Vincent', 'Botany', '24th editi', '1234', 'print output.docx', '03:14 pm on Tuesday 1st October 2019'),
(30, 'baze', 'Drew Salamone', 'Crop_Science', '24th editi', '1234', '341 note.pdf', '03:16 pm on Tuesday 1st October 2019'),
(31, 'File organization and managements', 'Christian Nwachukwu', 'Crop_Science', '24th editi', '1234', 'Cache fetch and replacement policies.pdf', '04:00 pm on Tuesday 1st October 2019'),
(32, 'File organization and managements', 'Christian Nwachukwu', 'Applied_Chemistry', '24th editi', '1234', 'CSC301_Intro to Java''s Architecture.pdf', '04:03 pm on Tuesday 1st October 2019'),
(33, 'chisom', 'Christian Nwachukwu', 'Computer_Science', '24th editi', '1234', '3-540-54444-5_98.pdf', '04:05 pm on Tuesday 1st October 2019');

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE `journals` (
  `id` int(10) NOT NULL auto_increment,
  `articletitle` varchar(100) NOT NULL,
  `journaltitle` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL,
  `category` varchar(20) NOT NULL,
  `database` varchar(100) NOT NULL,
  `volume` varchar(10) NOT NULL,
  `doi` varchar(20) NOT NULL,
  `date` varchar(100) NOT NULL,
  `filename` varchar(200) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `journals`
--

INSERT INTO `journals` (`id`, `articletitle`, `journaltitle`, `author`, `category`, `database`, `volume`, `doi`, `date`, `filename`) VALUES
(1, 'u7', 'lk', 'klio', 'Oceanography', '', '456', '9973456789', '04:34 am on Sunday 29th September 2019', '0'),
(2, 'articls', 'jon titl', 'chris', 'Social Sciences', '', '0', 'doi', '05:48 pm on Tuesday 1st October 2019', '0'),
(3, 'articls', 'jon titl', 'chris', 'Arts', '', '0', 'doi', '05:59 pm on Tuesday 1st October 2019', '0'),
(4, 'd', 'd', 'd', 'Arts', '', '0', 'd', '06:00 pm on Tuesday 1st October 2019', '0'),
(5, 'articls', 'jon titl', 'chris', 'Physical Science', '', 'vol', 'doi', '06:04 pm on Tuesday 1st October 2019', 'csc 202 assignment.docx'),
(6, 'articls', 'jon titl', 'chris', 'Engineering', '', 'vol', 'doi', '01:40 pm on Friday 4th October 2019', 'DATA STRUCTURE TEXT BOOK.pdf'),
(7, 'articls', 'jon titl', 'chris', 'Engineering', '', 'vol', 'doi', '01:40 pm on Friday 4th October 2019', 'GT-Lec4.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `reg_pin`
--

CREATE TABLE `reg_pin` (
  `pin_id` int(100) NOT NULL auto_increment,
  `pin` varchar(20) NOT NULL,
  `date_sent` varchar(50) NOT NULL,
  PRIMARY KEY  (`pin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `reg_pin`
--

INSERT INTO `reg_pin` (`pin_id`, `pin`, `date_sent`) VALUES
(1, 'UC7163697', 'Sat 28th Sep 2019, 12:09:23 am'),
(2, 'UC6136475', 'Sat 28th Sep 2019, 08:09:15 am'),
(3, 'UC3594056', 'Sun 29th Sep 2019, 03:09:53 pm');

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `resource_id` int(10) NOT NULL auto_increment,
  `resourcetitle` varchar(200) NOT NULL,
  `author` varchar(50) NOT NULL,
  `category` varchar(25) NOT NULL,
  `type` varchar(20) NOT NULL,
  `month` varchar(12) NOT NULL,
  `year` varchar(4) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY  (`resource_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`resource_id`, `resourcetitle`, `author`, `category`, `type`, `month`, `year`, `filename`, `date`) VALUES
(1, 'Workers', 'Sommy', 'Engineering', 'Arts', 'March', '1994', '10_chapter2.pdf', '04:56 am on Sunday 29th September 2019'),
(2, 'title', 'author', 'Management Sciences', 'Arts', 'month', '1233', 'Programming language design and analysis.pdf', '09:42 pm on Tuesday 1st October 2019'),
(3, 'title', 'author', 'Arts', 'Social Sciences', 'month', '2132', 'invariants.pdf', '10:05 pm on Tuesday 1st October 2019');

-- --------------------------------------------------------

--
-- Table structure for table `saved_books`
--

CREATE TABLE `saved_books` (
  `save_id` int(20) NOT NULL auto_increment,
  `book_id` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `saved_date` varchar(30) NOT NULL,
  PRIMARY KEY  (`save_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `saved_books`
--

INSERT INTO `saved_books` (`save_id`, `book_id`, `user_id`, `table_name`, `saved_date`) VALUES
(17, '1', 'chris', 'resources', '9:40am on Friday 4th October 2'),
(18, '2', 'chris', 'resources', '9:41am on Friday 4th October 2'),
(19, '32', 'chris', 'books', '9:44am on Friday 4th October 2'),
(20, '28', 'chris', 'books', '9:44am on Friday 4th October 2'),
(21, '29', 'chris', 'books', '9:44am on Friday 4th October 2'),
(22, '1', 'chris', 'thesis', '9:49am on Friday 4th October 2'),
(23, '22', 'chris', 'books', '10:00am on Friday 4th October '),
(24, '2', 'chris', 'books', '10:09am on Friday 4th October '),
(26, '2', 'chris', 'journals', '10:14am on Friday 4th October '),
(27, '12', 'chisom', 'books', '1:38pm on Friday 4th October 2');

-- --------------------------------------------------------

--
-- Table structure for table `thesis`
--

CREATE TABLE `thesis` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `author` varchar(50) NOT NULL,
  `level` varchar(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `department` varchar(100) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `thesis`
--

INSERT INTO `thesis` (`id`, `title`, `author`, `level`, `year`, `department`, `filename`, `date`) VALUES
(1, 'Test Thesis', 'Stanley', 'doc', '2015', '', 'Predicting Friendship Strength in Facebook.pdf', '05:11 am on Sunday 29th September 2019'),
(2, 'chisom', 'e', 'msc', '1223', '', 'CSC202 Assignment.pdf', '10:45 pm on Tuesday 1st October 2019');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(15) NOT NULL auto_increment,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fullname`, `username`, `password`, `category`) VALUES
(1, 'christian nwachukwu', 'chris', '1234', '300L'),
(2, '', '00006', '1234', ''),
(3, ' ', 'errice', '1234', 'Student'),
(4, ' ', 'errice', '1234', 'Lecturer'),
(5, ' ', 'errice', '1234', 'Lecturer'),
(6, ' ', 'errice', '1234', 'Lecturer'),
(7, ' ', 'errice', 'd', 'Lecturer'),
(8, ' ', 'errice', 'd', 'Lecturer'),
(9, ' ', 'errice', 'd', 'Lecturer'),
(10, ' ', 'errice', 'd', 'Lecturer'),
(11, ' ', 'errice', 'd', 'Lecturer'),
(12, ' ', 'ubasecure@yahoo.com', 'd', 'Student'),
(13, ' ', 'd', 'd', 'Student'),
(14, ' ', 'web.vixgog@gmail.com', 'd', 'Student'),
(15, ' ', 'steven', 's', 'Student'),
(16, ' ', 'steven', 's', 'Student'),
(17, ' ', 'ubasecure@yahoo.com', 'd', 'Student'),
(18, ' ', 'ubasecure@yahoo.com', 'd', 'Student'),
(19, ' ', 'errice', 'w', 'Student'),
(20, ' ', 's', 's', 'Lecturer'),
(21, ' ', 'chisom', '1234', 'Student');
